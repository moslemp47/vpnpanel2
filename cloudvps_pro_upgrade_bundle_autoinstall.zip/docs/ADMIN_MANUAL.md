# Admin Manual

Managing users, plans, servers (Marzban/Sanaei), tickets, finance.