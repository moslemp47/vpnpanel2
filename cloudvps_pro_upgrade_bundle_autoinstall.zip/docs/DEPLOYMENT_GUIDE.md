# Deployment Guide

Docker, k8s, blue‑green, backups, scaling.