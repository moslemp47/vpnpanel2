# Developer Guide

Project structure, API versioning, testing, CI/CD, coding standards.