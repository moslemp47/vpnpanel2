# Security Best Practices

Headers, rate limits, WAF, Cloudflare, secrets, audit logs.